package com.offer.mgmt.exception;

public class ResourceNotFoundException extends RuntimeException{
}
