package com.offer.mgmt.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection="transaction")
@JsonIgnoreProperties
public class Transaction {

    private String accountNumber;
    private Double carbonBalance;
    private String transactionId;
    public String getAccountNumber() {
        return accountNumber;
    }

    public Transaction setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
        return this;
    }

    public Double getCarbonBalance() {
        return carbonBalance;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public Transaction setTransactionId(String transactionId) {
        this.transactionId = transactionId;
        return this;
    }

    public Transaction setCarbonBalance(Double carbonBalance) {
        this.carbonBalance = carbonBalance;
        return this;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "accountNumber='" + accountNumber + '\'' +
                ", carbonBalance=" + carbonBalance +
                ", transactionId='" + transactionId + '\'' +
                '}';
    }
}
